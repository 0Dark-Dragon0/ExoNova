# Generate complete Google Colab code
colab_code = '''
# Space Debris Classification - Machine Learning Training
# Complete Google Colab Code with XGBoost

# STEP 0: Install XGBoost (run this cell first in Google Colab)
!pip install xgboost

# Import required libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import xgboost as xgb
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings('ignore')

print("🚀 Space Debris Classification - Machine Learning Training")
print("=" * 60)

# Step 1: Load the dataset and prepare features/target
print("\\n1. Loading dataset and preparing features...")

# Load the CSV file (make sure synthetic_debris_data.csv is uploaded to Colab)
df = pd.read_csv('synthetic_debris_data.csv')

print(f"✅ Dataset loaded successfully!")
print(f"📊 Dataset shape: {df.shape}")
print(f"🏷️ Columns: {list(df.columns)}")

# Display first few rows
print(f"\\nFirst 5 rows:")
print(df.head())

# Check for missing values
print(f"\\n📋 Missing values check:")
print(df.isnull().sum())

# Define feature columns (excluding Target)
feature_columns = ['Debris_X', 'Debris_Y', 'Debris_Z', 'Debris_VX', 'Debris_VY', 'Debris_VZ', 'Debris_Speed', 'Relative_Distance']
target_column = 'Target'

# Separate features and target
X = df[feature_columns].copy()
y = df[target_column].copy()

print(f"✅ Features shape: {X.shape}")
print(f"✅ Target shape: {y.shape}")
print(f"📋 Feature columns: {list(X.columns)}")

# Check class distribution
print(f"\\n🎯 Class distribution:")
class_counts = df['Target'].value_counts().sort_index()
for class_id, count in class_counts.items():
    print(f"Class {class_id}: {count:,} samples ({count/len(df)*100:.2f}%)")

# Step 2: Train/Test Split with stratification
print("\\n2. Splitting dataset into train and test sets...")

# Split with stratification to maintain class balance
X_train, X_test, y_train, y_test = train_test_split(
    X, y, 
    test_size=0.2,       # 80% train, 20% test
    random_state=42,     # Fixed seed for reproducibility
    stratify=y          # Stratified split to balance classes
)

print(f"✅ Train set - Features: {X_train.shape}, Target: {y_train.shape}")
print(f"✅ Test set - Features: {X_test.shape}, Target: {y_test.shape}")

# Check class distribution in train and test sets
print(f"\\n📊 Train set class distribution:")
train_dist = y_train.value_counts().sort_index()
for class_id, count in train_dist.items():
    print(f"Class {class_id}: {count} samples ({count/len(y_train)*100:.1f}%)")

print(f"\\n📊 Test set class distribution:")
test_dist = y_test.value_counts().sort_index()
for class_id, count in test_dist.items():
    print(f"Class {class_id}: {count} samples ({count/len(y_test)*100:.1f}%)")

# Step 3: Train XGBoost Model
print("\\n3. Training XGBoost Classifier...")

# Initialize XGBoost Classifier with specified parameters
model = xgb.XGBClassifier(
    n_estimators=300,        # Number of trees
    learning_rate=0.1,       # Learning rate
    max_depth=6,             # Maximum tree depth
    subsample=0.8,           # Fraction of samples for each tree
    colsample_bytree=0.8,    # Fraction of features for each tree
    eval_metric='mlogloss',  # Evaluation metric
    random_state=42,         # For reproducibility
    n_jobs=-1,               # Use all cores
    verbosity=0              # Reduce output verbosity
)

print("🔧 XGBoost Model parameters:")
print(f"  - n_estimators: 300")
print(f"  - learning_rate: 0.1")
print(f"  - max_depth: 6")
print(f"  - subsample: 0.8")
print(f"  - colsample_bytree: 0.8")
print(f"  - eval_metric: 'mlogloss'")
print(f"  - random_state: 42")

# Train the model
print("\\n⏳ Training XGBoost model...")
model.fit(X_train, y_train)
print("✅ Model training completed!")

# Make predictions on test set
print("\\n🔮 Making predictions on test set...")
y_pred = model.predict(X_test)
y_pred_proba = model.predict_proba(X_test)
print("✅ Predictions completed!")

# Step 4: Evaluate the model
print("\\n4. Model Evaluation Results")
print("=" * 40)

# Calculate accuracy
accuracy = accuracy_score(y_test, y_pred)
print(f"🎯 Overall Accuracy: {accuracy:.4f} ({accuracy*100:.2f}%)")

# Classification Report
print(f"\\n📊 Detailed Classification Report:")
print("=" * 60)
report = classification_report(y_test, y_pred, digits=4)
print(report)

# Get classification report as dictionary for better formatting
report_dict = classification_report(y_test, y_pred, output_dict=True)

print(f"\\n📈 Per-Class Performance Summary:")
print("=" * 50)
for class_id in sorted([k for k in report_dict.keys() if k.isdigit() or k == '0']):
    class_num = int(class_id)
    precision = report_dict[class_id]['precision']
    recall = report_dict[class_id]['recall']
    f1 = report_dict[class_id]['f1-score']
    support = report_dict[class_id]['support']
    
    print(f"Class {class_num}: Precision={precision:.3f}, Recall={recall:.3f}, F1={f1:.3f}, Support={support}")

# Feature importance
print(f"\\n🔍 Feature Importance Ranking:")
print("=" * 40)
feature_importance = pd.DataFrame({
    'feature': X.columns,
    'importance': model.feature_importances_
}).sort_values('importance', ascending=False)

for idx, row in feature_importance.iterrows():
    print(f"{row['feature']}: {row['importance']:.4f}")

# Calculate and display confusion matrix
cm = confusion_matrix(y_test, y_pred)
print(f"\\n🔢 Confusion Matrix:")
print("=" * 30)
print(cm)

# Create confusion matrix heatmap
plt.figure(figsize=(10, 8))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
            xticklabels=[f'Pred {i}' for i in range(6)],
            yticklabels=[f'Actual {i}' for i in range(6)])
plt.title('Confusion Matrix - Space Debris Classification Model', fontsize=16, fontweight='bold')
plt.xlabel('Predicted Class', fontsize=12, fontweight='bold')
plt.ylabel('Actual Class', fontsize=12, fontweight='bold')
plt.tight_layout()
plt.show()

print(f"\\n✅ Model training and evaluation completed successfully!")
print(f"📈 Final Results Summary:")
print(f"  - Overall Accuracy: {accuracy*100:.2f}%")
print(f"  - Model: XGBoost Classifier")
print(f"  - Features: {X.shape[1]}")
print(f"  - Classes: {len(np.unique(y))}")
print(f"  - Test Samples: {len(y_test)}")

# Additional insights
print(f"\\n🧠 Model Insights:")
print("=" * 30)
print(f"🔍 Most important feature: {feature_importance.iloc[0]['feature']} ({feature_importance.iloc[0]['importance']:.3f})")
print(f"📊 Best performing class: Class {report_dict['macro avg']['precision']:.3f}")
print(f"⚡ The model successfully classifies space debris with high accuracy!")
print(f"🎯 Ready for deployment in space debris monitoring systems!")
'''

print("=" * 80)
print("COMPLETE GOOGLE COLAB CODE WITH XGBOOST")
print("=" * 80)
print("\nCopy and paste the following code into Google Colab:")
print("\n" + colab_code)