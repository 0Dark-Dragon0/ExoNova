# Step 3: Train the model (using RandomForest as XGBoost alternative)
print("\n3. Training the machine learning model...")

# Since XGBoost is not available, we'll use RandomForestClassifier with similar parameters
# RandomForest parameters that roughly correspond to XGBoost settings:
model = RandomForestClassifier(
    n_estimators=300,      # Similar to XGBoost n_estimators
    max_depth=6,           # Same as XGBoost max_depth
    max_features='sqrt',   # Similar to colsample_bytree
    random_state=42,       # For reproducibility
    n_jobs=-1,             # Use all cores for faster training
    class_weight='balanced'  # Handle class imbalance
)

print("🔧 Model parameters:")
print(f"  - n_estimators: 300")
print(f"  - max_depth: 6") 
print(f"  - max_features: 'sqrt'")
print(f"  - random_state: 42")
print(f"  - class_weight: 'balanced'")

# Train the model
print("\n⏳ Training in progress...")
model.fit(X_train, y_train)
print("✅ Model training completed!")

# Make predictions on test set
print("\n🔮 Making predictions on test set...")
y_pred = model.predict(X_test)
y_pred_proba = model.predict_proba(X_test)

print("✅ Predictions completed!")