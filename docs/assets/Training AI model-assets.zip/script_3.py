# First, let's recreate the dataset quickly for ML training
import pandas as pd
import numpy as np

# Set random seed
np.random.seed(42)

# Generate a smaller dataset for demonstration (10,000 samples)
n_samples = 10000

# Generate random position coordinates
debris_x = np.random.uniform(-1000, 1000, n_samples)
debris_y = np.random.uniform(-1000, 1000, n_samples)
debris_z = np.random.uniform(-1000, 1000, n_samples)

# Generate random velocity components
debris_vx = np.random.uniform(-50, 50, n_samples)
debris_vy = np.random.uniform(-50, 50, n_samples)
debris_vz = np.random.uniform(-50, 50, n_samples)

# Calculate derived features
debris_speed = np.sqrt(debris_vx**2 + debris_vy**2 + debris_vz**2)
relative_distance = np.sqrt(debris_x**2 + debris_y**2 + debris_z**2)

# Initialize target array
target = np.zeros(n_samples, dtype=int)

# Apply classification rules (in order of priority)
mask_5 = (relative_distance < 200) & (debris_speed > 30)
target[mask_5] = 5

mask_4 = (relative_distance < 400) & (debris_speed > 25) & (target == 0)
target[mask_4] = 4

mask_3 = (relative_distance < 600) & (debris_speed > 20) & (target == 0)
target[mask_3] = 3

mask_2 = (relative_distance < 800) & (debris_speed > 15) & (target == 0)
target[mask_2] = 2

mask_1 = (relative_distance < 1000) & (debris_speed > 10) & (target == 0)
target[mask_1] = 1

# Create DataFrame
df = pd.DataFrame({
    'Debris_X': debris_x,
    'Debris_Y': debris_y,
    'Debris_Z': debris_z,
    'Debris_VX': debris_vx,
    'Debris_VY': debris_vy,
    'Debris_VZ': debris_vz,
    'Debris_Speed': debris_speed,
    'Relative_Distance': relative_distance,
    'Target': target
})

# Save as CSV
df.to_csv('synthetic_debris_data.csv', index=False)

print("✅ Dataset recreated and saved as 'synthetic_debris_data.csv'")
print(f"📊 Dataset shape: {df.shape}")
print(f"🎯 Class distribution:")
class_counts = df['Target'].value_counts().sort_index()
for class_id, count in class_counts.items():
    print(f"Class {class_id}: {count:,} samples ({count/len(df)*100:.2f}%)")