# Step 4: Evaluate the model
print("\n4. Model Evaluation Results")
print("=" * 40)

# Calculate accuracy
accuracy = accuracy_score(y_test, y_pred)
print(f"🎯 Overall Accuracy: {accuracy:.4f} ({accuracy*100:.2f}%)")

# Classification Report
print(f"\n📊 Detailed Classification Report:")
print("=" * 60)
report = classification_report(y_test, y_pred, digits=4)
print(report)

# Get classification report as dictionary for better formatting
report_dict = classification_report(y_test, y_pred, output_dict=True)

print(f"\n📈 Per-Class Performance Summary:")
print("=" * 50)
for class_id in sorted([k for k in report_dict.keys() if k.isdigit() or k == '0']):
    class_num = int(class_id)
    precision = report_dict[class_id]['precision']
    recall = report_dict[class_id]['recall']
    f1 = report_dict[class_id]['f1-score']
    support = report_dict[class_id]['support']
    
    print(f"Class {class_num}: Precision={precision:.3f}, Recall={recall:.3f}, F1={f1:.3f}, Support={support}")

# Feature importance
print(f"\n🔍 Top 5 Most Important Features:")
print("=" * 40)
feature_importance = pd.DataFrame({
    'feature': X.columns,
    'importance': model.feature_importances_
}).sort_values('importance', ascending=False)

for idx, row in feature_importance.head(5).iterrows():
    print(f"{row['feature']}: {row['importance']:.4f}")

print(f"\nFull feature importance ranking:")
for idx, row in feature_importance.iterrows():
    print(f"{row['feature']}: {row['importance']:.4f}")