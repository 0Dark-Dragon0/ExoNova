# Step 2: Train/Test Split with stratification
print("\n2. Splitting dataset into train and test sets...")

# Split with stratification to maintain class balance
X_train, X_test, y_train, y_test = train_test_split(
    X, y, 
    test_size=0.2,       # 80% train, 20% test
    random_state=42,     # Fixed seed for reproducibility
    stratify=y          # Stratified split to balance classes
)

print(f"✅ Train set - Features: {X_train.shape}, Target: {y_train.shape}")
print(f"✅ Test set - Features: {X_test.shape}, Target: {y_test.shape}")

# Check class distribution in train and test sets
print(f"\n📊 Train set class distribution:")
train_dist = y_train.value_counts().sort_index()
for class_id, count in train_dist.items():
    print(f"Class {class_id}: {count} samples ({count/len(y_train)*100:.1f}%)")

print(f"\n📊 Test set class distribution:")
test_dist = y_test.value_counts().sort_index()
for class_id, count in test_dist.items():
    print(f"Class {class_id}: {count} samples ({count/len(y_test)*100:.1f}%)")