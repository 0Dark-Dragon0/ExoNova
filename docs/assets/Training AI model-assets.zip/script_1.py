# Complete Machine Learning Training Code for Space Debris Classification
# Google Colab Ready Code (with XGBoost installation)

# Import required libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.ensemble import RandomForestClassifier  # Alternative to XGBoost for now
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings('ignore')

print("🚀 Space Debris Classification - Machine Learning Training")
print("=" * 60)

# Step 1: Load the dataset
print("\n1. Loading the synthetic debris dataset...")
try:
    # Load the CSV file
    df = pd.read_csv('synthetic_debris_data.csv')
    print(f"✅ Dataset loaded successfully!")
    print(f"📊 Dataset shape: {df.shape}")
    print(f"🏷️ Columns: {list(df.columns)}")
    
    # Display first few rows
    print(f"\nFirst 5 rows:")
    print(df.head())
    
except FileNotFoundError:
    print("❌ Error: synthetic_debris_data.csv not found!")
    print("Please make sure the dataset file is in the same directory.")
    
# Check for missing values
print(f"\n📋 Missing values check:")
missing_values = df.isnull().sum()
print(missing_values)

# Check class distribution
print(f"\n🎯 Class distribution:")
class_counts = df['Target'].value_counts().sort_index()
for class_id, count in class_counts.items():
    print(f"Class {class_id}: {count:,} samples ({count/len(df)*100:.2f}%)")