# Check available files
import os
print("Available files:")
for file in os.listdir():
    if file.endswith('.csv'):
        print(f"  {file}")

# Let's also check if we have the synthetic data from previous execution
try:
    # Try to load the dataset
    df = pd.read_csv('synthetic_debris_data.csv')
    print(f"✅ Found synthetic_debris_data.csv with shape: {df.shape}")
except:
    print("❌ synthetic_debris_data.csv not found. Let me check the columns...")
    
# Let's recreate a small sample to test the ML pipeline
print("\nCreating sample data for testing ML pipeline...")