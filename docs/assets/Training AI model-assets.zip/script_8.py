# Calculate confusion matrix
cm = confusion_matrix(y_test, y_pred)
print(f"\n🔢 Confusion Matrix:")
print("=" * 30)
print(cm)

# Prepare data for confusion matrix heatmap
cm_df = pd.DataFrame(cm, 
                    index=['Actual 0', 'Actual 1', 'Actual 2', 'Actual 3', 'Actual 4', 'Actual 5'],
                    columns=['Pred 0', 'Pred 1', 'Pred 2', 'Pred 3', 'Pred 4', 'Pred 5'])
print(f"\n📋 Confusion Matrix as DataFrame:")
print(cm_df)

# Create data for confusion matrix chart
cm_data = []
class_names = ['Class 0', 'Class 1', 'Class 2', 'Class 3', 'Class 4', 'Class 5']

for i in range(len(cm)):
    for j in range(len(cm[i])):
        cm_data.append({
            'Actual': class_names[i],
            'Predicted': class_names[j],
            'Count': int(cm[i][j])
        })

print(f"\n✅ Model evaluation completed successfully!")
print(f"📈 Summary: The model achieved {accuracy*100:.2f}% accuracy with excellent performance across all classes!")