# Complete Machine Learning Training Code for Space Debris Classification
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings('ignore')

print("🚀 Space Debris Classification - Machine Learning Training")
print("=" * 60)

# Step 1: Load the dataset and prepare features/target
print("\n1. Loading dataset and preparing features...")

# Define feature columns (excluding Target)
feature_columns = ['Debris_X', 'Debris_Y', 'Debris_Z', 'Debris_VX', 'Debris_VY', 'Debris_VZ', 'Debris_Speed', 'Relative_Distance']
target_column = 'Target'

# Separate features and target
X = df[feature_columns].copy()
y = df[target_column].copy()

print(f"✅ Features shape: {X.shape}")
print(f"✅ Target shape: {y.shape}")
print(f"📋 Feature columns: {list(X.columns)}")
print(f"\nFeature statistics:")
print(X.describe())

print(f"\nTarget distribution:")
target_dist = y.value_counts().sort_index()
for class_id, count in target_dist.items():
    print(f"Class {class_id}: {count} samples")