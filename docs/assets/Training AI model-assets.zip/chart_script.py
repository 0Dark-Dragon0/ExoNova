import pandas as pd
import plotly.graph_objects as go
import numpy as np

# Create DataFrame from the provided data
data = {
    "Actual": ["Class 0", "Class 0", "Class 0", "Class 0", "Class 0", "Class 0", 
               "Class 1", "Class 1", "Class 1", "Class 1", "Class 1", "Class 1", 
               "Class 2", "Class 2", "Class 2", "Class 2", "Class 2", "Class 2", 
               "Class 3", "Class 3", "Class 3", "Class 3", "Class 3", "Class 3", 
               "Class 4", "Class 4", "Class 4", "Class 4", "Class 4", "Class 4", 
               "Class 5", "Class 5", "Class 5", "Class 5", "Class 5", "Class 5"],
    "Predicted": ["Class 0", "Class 1", "Class 2", "Class 3", "Class 4", "Class 5", 
                  "Class 0", "Class 1", "Class 2", "Class 3", "Class 4", "Class 5", 
                  "Class 0", "Class 1", "Class 2", "Class 3", "Class 4", "Class 5", 
                  "Class 0", "Class 1", "Class 2", "Class 3", "Class 4", "Class 5", 
                  "Class 0", "Class 1", "Class 2", "Class 3", "Class 4", "Class 5", 
                  "Class 0", "Class 1", "Class 2", "Class 3", "Class 4", "Class 5"],
    "Count": [947, 1, 0, 0, 0, 0, 0, 515, 9, 2, 2, 0, 0, 0, 297, 2, 2, 1, 0, 0, 0, 151, 3, 0, 0, 0, 0, 0, 59, 1, 0, 0, 0, 0, 0, 8]
}

df = pd.DataFrame(data)

# Extract class numbers for matrix indexing
df['Actual_Class'] = df['Actual'].str.extract('(\d+)').astype(int)
df['Predicted_Class'] = df['Predicted'].str.extract('(\d+)').astype(int)

# Create 6x6 confusion matrix
confusion_matrix = np.zeros((6, 6))
for _, row in df.iterrows():
    confusion_matrix[row['Actual_Class'], row['Predicted_Class']] = row['Count']

# Create text annotations for each cell
text_annotations = confusion_matrix.astype(int).astype(str)

# Create heatmap
fig = go.Figure(data=go.Heatmap(
    z=confusion_matrix,
    text=text_annotations,
    texttemplate="%{text}",
    textfont={"size": 14},
    colorscale='Blues',
    showscale=True,
    hoverongaps=False,
    hovertemplate='Actual: %{y}<br>Predicted: %{x}<br>Count: %{z}<extra></extra>'
))

fig.update_layout(
    title="Space Debris Classification Matrix",
    xaxis_title="Predicted",
    yaxis_title="Actual"
)

fig.update_xaxes(
    tickvals=[0, 1, 2, 3, 4, 5],
    ticktext=['0', '1', '2', '3', '4', '5'],
    side='bottom'
)

fig.update_yaxes(
    tickvals=[0, 1, 2, 3, 4, 5],
    ticktext=['0', '1', '2', '3', '4', '5'],
    autorange='reversed'
)

fig.write_image("confusion_matrix.png")