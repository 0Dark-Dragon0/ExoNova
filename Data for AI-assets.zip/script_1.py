# The dataset is quite imbalanced. Let's create a balanced version.
# We'll sample equal numbers from each class to create a balanced dataset

# Find the class with minimum samples (excluding class 5 which is very small)
# Let's aim for about 15,000 samples per class for a total of ~90,000 samples
target_samples_per_class = 15000

print("Creating balanced dataset...")

# Separate data by class
class_dataframes = {}
for class_id in range(6):
    class_dataframes[class_id] = df_initial[df_initial['Target'] == class_id]

# For classes with fewer samples than target, we'll generate more data
balanced_dfs = []

for class_id in range(6):
    current_class_df = class_dataframes[class_id]
    current_count = len(current_class_df)
    
    print(f"Class {class_id}: {current_count} samples")
    
    if current_count >= target_samples_per_class:
        # Sample down to target
        sampled_df = current_class_df.sample(n=target_samples_per_class, random_state=42)
        balanced_dfs.append(sampled_df)
    else:
        # We need to generate more samples for this class
        # Use all existing samples and generate additional ones
        additional_needed = target_samples_per_class - current_count
        
        # Generate additional samples with parameters that favor this class
        if class_id == 5:  # Class 5: distance < 200 AND speed > 30
            x = np.random.uniform(-200, 200, additional_needed)
            y = np.random.uniform(-200, 200, additional_needed) 
            z = np.random.uniform(-200, 200, additional_needed)
            vx = np.random.uniform(-50, 50, additional_needed)
            vy = np.random.uniform(-50, 50, additional_needed)
            vz = np.random.uniform(25, 50, additional_needed)  # Favor higher speeds
        elif class_id == 4:  # Class 4: distance < 400 AND speed > 25
            x = np.random.uniform(-400, 400, additional_needed)
            y = np.random.uniform(-400, 400, additional_needed)
            z = np.random.uniform(-400, 400, additional_needed)
            vx = np.random.uniform(-50, 50, additional_needed)
            vy = np.random.uniform(-50, 50, additional_needed)
            vz = np.random.uniform(20, 40, additional_needed)  # Favor higher speeds
        elif class_id == 3:  # Class 3: distance < 600 AND speed > 20
            x = np.random.uniform(-600, 600, additional_needed)
            y = np.random.uniform(-600, 600, additional_needed)
            z = np.random.uniform(-600, 600, additional_needed)
            vx = np.random.uniform(-40, 40, additional_needed)
            vy = np.random.uniform(-40, 40, additional_needed)
            vz = np.random.uniform(15, 35, additional_needed)
        else:
            # For other classes, use standard generation
            x = np.random.uniform(-1000, 1000, additional_needed)
            y = np.random.uniform(-1000, 1000, additional_needed)
            z = np.random.uniform(-1000, 1000, additional_needed)
            vx = np.random.uniform(-50, 50, additional_needed)
            vy = np.random.uniform(-50, 50, additional_needed)
            vz = np.random.uniform(-50, 50, additional_needed)
        
        # Calculate derived features
        speed = np.sqrt(vx**2 + vy**2 + vz**2)
        distance = np.sqrt(x**2 + y**2 + z**2)
        
        # Apply classification rules
        target_new = np.zeros(additional_needed, dtype=int)
        
        mask_5 = (distance < 200) & (speed > 30)
        target_new[mask_5] = 5
        
        mask_4 = (distance < 400) & (speed > 25) & (target_new == 0)
        target_new[mask_4] = 4
        
        mask_3 = (distance < 600) & (speed > 20) & (target_new == 0)
        target_new[mask_3] = 3
        
        mask_2 = (distance < 800) & (speed > 15) & (target_new == 0)
        target_new[mask_2] = 2
        
        mask_1 = (distance < 1000) & (speed > 10) & (target_new == 0)
        target_new[mask_1] = 1
        
        # Create additional dataframe
        additional_df = pd.DataFrame({
            'Debris_X': x,
            'Debris_Y': y,
            'Debris_Z': z,
            'Debris_VX': vx,
            'Debris_VY': vy,
            'Debris_VZ': vz,
            'Debris_Speed': speed,
            'Relative_Distance': distance,
            'Target': target_new
        })
        
        # Filter to keep only samples of the desired class
        additional_df_filtered = additional_df[additional_df['Target'] == class_id]
        
        # Combine with existing samples
        combined_df = pd.concat([current_class_df, additional_df_filtered], ignore_index=True)
        
        # Sample to exact target
        final_df = combined_df.sample(n=min(target_samples_per_class, len(combined_df)), random_state=42)
        balanced_dfs.append(final_df)

print(f"\nBalanced dataset creation completed.")