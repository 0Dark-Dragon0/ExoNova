# Combine all balanced dataframes
balanced_df = pd.concat(balanced_dfs, ignore_index=True)

# Shuffle the dataset
balanced_df = balanced_df.sample(frac=1, random_state=42).reset_index(drop=True)

print("Final balanced dataset created!")
print(f"Dataset shape: {balanced_df.shape}")

# Check final class distribution
print("\nFinal class distribution:")
final_class_counts = balanced_df['Target'].value_counts().sort_index()
print(final_class_counts)
print(f"\nPercentages:")
for class_id, count in final_class_counts.items():
    print(f"Class {class_id}: {count/len(balanced_df)*100:.2f}%")

# Show first 10 rows
print(f"\nFirst 10 rows of the dataset:")
print(balanced_df.head(10))

# Show basic statistics
print(f"\nDataset statistics:")
print(balanced_df.describe())

# Save as CSV
csv_filename = 'synthetic_debris_data.csv'
balanced_df.to_csv(csv_filename, index=False)
print(f"\nDataset saved as '{csv_filename}'")

# Prepare data for visualization
class_distribution_data = balanced_df['Target'].value_counts().sort_index()
print(f"\nClass distribution for chart:")
for class_id, count in class_distribution_data.items():
    print(f"Class {class_id}: {count}")