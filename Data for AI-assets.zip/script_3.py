# Create complete Google Colab-ready code
colab_code = '''
# Space Debris Classification - Synthetic Dataset Generation
# Complete Google Colab Code

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Set random seed for reproducibility
np.random.seed(42)

def generate_debris_data(n_samples=100000):
    """Generate synthetic space debris data with specified features."""
    # Generate random position coordinates
    debris_x = np.random.uniform(-1000, 1000, n_samples)
    debris_y = np.random.uniform(-1000, 1000, n_samples)
    debris_z = np.random.uniform(-1000, 1000, n_samples)
    
    # Generate random velocity components
    debris_vx = np.random.uniform(-50, 50, n_samples)
    debris_vy = np.random.uniform(-50, 50, n_samples)
    debris_vz = np.random.uniform(-50, 50, n_samples)
    
    # Calculate derived features
    debris_speed = np.sqrt(debris_vx**2 + debris_vy**2 + debris_vz**2)
    relative_distance = np.sqrt(debris_x**2 + debris_y**2 + debris_z**2)
    
    # Initialize target array
    target = np.zeros(n_samples, dtype=int)
    
    # Apply classification rules (in order of priority)
    # Class 5: distance < 200 AND speed > 30
    mask_5 = (relative_distance < 200) & (debris_speed > 30)
    target[mask_5] = 5
    
    # Class 4: distance < 400 AND speed > 25 (and not already classified)
    mask_4 = (relative_distance < 400) & (debris_speed > 25) & (target == 0)
    target[mask_4] = 4
    
    # Class 3: distance < 600 AND speed > 20 (and not already classified)
    mask_3 = (relative_distance < 600) & (debris_speed > 20) & (target == 0)
    target[mask_3] = 3
    
    # Class 2: distance < 800 AND speed > 15 (and not already classified)
    mask_2 = (relative_distance < 800) & (debris_speed > 15) & (target == 0)
    target[mask_2] = 2
    
    # Class 1: distance < 1000 AND speed > 10 (and not already classified)
    mask_1 = (relative_distance < 1000) & (debris_speed > 10) & (target == 0)
    target[mask_1] = 1
    
    # Class 0: everything else (already initialized as 0)
    
    # Create DataFrame
    df = pd.DataFrame({
        'Debris_X': debris_x,
        'Debris_Y': debris_y,
        'Debris_Z': debris_z,
        'Debris_VX': debris_vx,
        'Debris_VY': debris_vy,
        'Debris_VZ': debris_vz,
        'Debris_Speed': debris_speed,
        'Relative_Distance': relative_distance,
        'Target': target
    })
    
    return df

def create_balanced_dataset(df_initial, target_samples_per_class=15000):
    """Create a balanced version of the dataset."""
    print("Creating balanced dataset...")
    
    # Separate data by class
    class_dataframes = {}
    for class_id in range(6):
        class_dataframes[class_id] = df_initial[df_initial['Target'] == class_id]
    
    balanced_dfs = []
    
    for class_id in range(6):
        current_class_df = class_dataframes[class_id]
        current_count = len(current_class_df)
        
        print(f"Class {class_id}: {current_count} samples")
        
        if current_count >= target_samples_per_class:
            # Sample down to target
            sampled_df = current_class_df.sample(n=target_samples_per_class, random_state=42)
            balanced_dfs.append(sampled_df)
        else:
            # Generate more samples for this class
            additional_needed = target_samples_per_class - current_count
            
            # Generate additional samples with parameters that favor this class
            if class_id == 5:  # Class 5: distance < 200 AND speed > 30
                x = np.random.uniform(-200, 200, additional_needed)
                y = np.random.uniform(-200, 200, additional_needed) 
                z = np.random.uniform(-200, 200, additional_needed)
                vx = np.random.uniform(-50, 50, additional_needed)
                vy = np.random.uniform(-50, 50, additional_needed)
                vz = np.random.uniform(25, 50, additional_needed)
            elif class_id == 4:  # Class 4: distance < 400 AND speed > 25
                x = np.random.uniform(-400, 400, additional_needed)
                y = np.random.uniform(-400, 400, additional_needed)
                z = np.random.uniform(-400, 400, additional_needed)
                vx = np.random.uniform(-50, 50, additional_needed)
                vy = np.random.uniform(-50, 50, additional_needed)
                vz = np.random.uniform(20, 40, additional_needed)
            elif class_id == 3:  # Class 3: distance < 600 AND speed > 20
                x = np.random.uniform(-600, 600, additional_needed)
                y = np.random.uniform(-600, 600, additional_needed)
                z = np.random.uniform(-600, 600, additional_needed)
                vx = np.random.uniform(-40, 40, additional_needed)
                vy = np.random.uniform(-40, 40, additional_needed)
                vz = np.random.uniform(15, 35, additional_needed)
            else:
                # For other classes, use standard generation
                x = np.random.uniform(-1000, 1000, additional_needed)
                y = np.random.uniform(-1000, 1000, additional_needed)
                z = np.random.uniform(-1000, 1000, additional_needed)
                vx = np.random.uniform(-50, 50, additional_needed)
                vy = np.random.uniform(-50, 50, additional_needed)
                vz = np.random.uniform(-50, 50, additional_needed)
            
            # Calculate derived features
            speed = np.sqrt(vx**2 + vy**2 + vz**2)
            distance = np.sqrt(x**2 + y**2 + z**2)
            
            # Apply classification rules
            target_new = np.zeros(additional_needed, dtype=int)
            
            mask_5 = (distance < 200) & (speed > 30)
            target_new[mask_5] = 5
            
            mask_4 = (distance < 400) & (speed > 25) & (target_new == 0)
            target_new[mask_4] = 4
            
            mask_3 = (distance < 600) & (speed > 20) & (target_new == 0)
            target_new[mask_3] = 3
            
            mask_2 = (distance < 800) & (speed > 15) & (target_new == 0)
            target_new[mask_2] = 2
            
            mask_1 = (distance < 1000) & (speed > 10) & (target_new == 0)
            target_new[mask_1] = 1
            
            # Create additional dataframe
            additional_df = pd.DataFrame({
                'Debris_X': x,
                'Debris_Y': y,
                'Debris_Z': z,
                'Debris_VX': vx,
                'Debris_VY': vy,
                'Debris_VZ': vz,
                'Debris_Speed': speed,
                'Relative_Distance': distance,
                'Target': target_new
            })
            
            # Filter to keep only samples of the desired class
            additional_df_filtered = additional_df[additional_df['Target'] == class_id]
            
            # Combine with existing samples
            combined_df = pd.concat([current_class_df, additional_df_filtered], ignore_index=True)
            
            # Sample to exact target
            final_df = combined_df.sample(n=min(target_samples_per_class, len(combined_df)), random_state=42)
            balanced_dfs.append(final_df)
    
    return balanced_dfs

# ===========================
# MAIN EXECUTION
# ===========================

print("🚀 Space Debris Classification Dataset Generation")
print("="*50)

# Step 1: Generate initial dataset
print("\\n1. Generating 100,000 rows of synthetic debris data...")
df_initial = generate_debris_data(100000)

print("\\nInitial class distribution:")
class_counts = df_initial['Target'].value_counts().sort_index()
for class_id, count in class_counts.items():
    print(f"Class {class_id}: {count:,} samples ({count/len(df_initial)*100:.2f}%)")

# Step 2: Create balanced dataset
print("\\n2. Creating balanced dataset...")
balanced_dfs = create_balanced_dataset(df_initial, target_samples_per_class=15000)

# Combine all balanced dataframes
balanced_df = pd.concat(balanced_dfs, ignore_index=True)
balanced_df = balanced_df.sample(frac=1, random_state=42).reset_index(drop=True)

print(f"\\nBalanced dataset shape: {balanced_df.shape}")

# Step 3: Show final class distribution
print("\\n3. Final class distribution:")
final_class_counts = balanced_df['Target'].value_counts().sort_index()
for class_id, count in final_class_counts.items():
    print(f"Class {class_id}: {count:,} samples ({count/len(balanced_df)*100:.2f}%)")

# Step 4: Show first 10 rows
print("\\n4. First 10 rows of the dataset:")
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)
print(balanced_df.head(10))

# Step 5: Save as CSV
csv_filename = 'synthetic_debris_data.csv'
balanced_df.to_csv(csv_filename, index=False)
print(f"\\n5. Dataset saved as '{csv_filename}'")

# Step 6: Create and show class distribution bar chart
print("\\n6. Creating class distribution visualization...")
plt.figure(figsize=(10, 6))
class_counts = balanced_df['Target'].value_counts().sort_index()

bars = plt.bar(class_counts.index, class_counts.values, 
               color=['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd', '#8c564b'],
               alpha=0.8, edgecolor='black', linewidth=1)

# Add value labels on bars
for bar, count in zip(bars, class_counts.values):
    plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 200,
             f'{count:,}', ha='center', va='bottom', fontsize=11, fontweight='bold')

plt.title('Class Distribution in Synthetic Space Debris Dataset', fontsize=16, fontweight='bold', pad=20)
plt.xlabel('Debris Class', fontsize=12, fontweight='bold')
plt.ylabel('Number of Samples', fontsize=12, fontweight='bold')
plt.xticks(range(6), fontsize=11)
plt.yticks(fontsize=11)
plt.grid(axis='y', alpha=0.3, linestyle='--')

# Add class descriptions
class_descriptions = [
    'Class 0: Low risk debris',
    'Class 1: Distance < 1000, Speed > 10',
    'Class 2: Distance < 800, Speed > 15', 
    'Class 3: Distance < 600, Speed > 20',
    'Class 4: Distance < 400, Speed > 25',
    'Class 5: Distance < 200, Speed > 30 (High risk)'
]

plt.figtext(0.02, 0.02, '\\n'.join(class_descriptions), fontsize=9, 
            bbox=dict(boxstyle="round,pad=0.3", facecolor="lightgray", alpha=0.8))

plt.tight_layout()
plt.show()

# Step 7: Dataset summary statistics
print("\\n7. Dataset Summary Statistics:")
print("="*40)
print(balanced_df.describe())

print("\\n✅ Dataset generation completed successfully!")
print(f"📁 File saved: {csv_filename}")
print(f"📊 Total samples: {len(balanced_df):,}")
print(f"🎯 Classes: {len(balanced_df['Target'].unique())}")
print(f"📈 Features: {balanced_df.shape[1]}")
'''

print("Complete Google Colab-ready code generated!")
print("="*50)
print("Copy and paste the following code into a Google Colab cell:")
print("="*50)
print(colab_code)