import plotly.graph_objects as go
import plotly.io as pio

# Data
classes = [0, 1, 2, 3, 4, 5]
counts = [15000, 15000, 15000, 10455, 8360, 7997]

# Format counts for display (abbreviate with k)
display_counts = ['15k', '15k', '15k', '10.46k', '8.36k', '8.00k']

# Create bar chart
fig = go.Figure(data=[
    go.Bar(
        x=classes,
        y=counts,
        text=display_counts,
        textposition='outside',
        marker_color='#1FB8CD',
        cliponaxis=False
    )
])

# Update layout
fig.update_layout(
    title="Class Distribution in Space Debris Data",
    xaxis_title="Class",
    yaxis_title="Count"
)

# Save the chart
fig.write_image("space_debris_class_distribution.png")