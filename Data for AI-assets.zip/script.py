import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Set random seed for reproducibility
np.random.seed(42)

# Function to generate synthetic debris data
def generate_debris_data(n_samples=100000):
    # Generate random position coordinates
    debris_x = np.random.uniform(-1000, 1000, n_samples)
    debris_y = np.random.uniform(-1000, 1000, n_samples)
    debris_z = np.random.uniform(-1000, 1000, n_samples)
    
    # Generate random velocity components
    debris_vx = np.random.uniform(-50, 50, n_samples)
    debris_vy = np.random.uniform(-50, 50, n_samples)
    debris_vz = np.random.uniform(-50, 50, n_samples)
    
    # Calculate derived features
    debris_speed = np.sqrt(debris_vx**2 + debris_vy**2 + debris_vz**2)
    relative_distance = np.sqrt(debris_x**2 + debris_y**2 + debris_z**2)
    
    # Initialize target array
    target = np.zeros(n_samples, dtype=int)
    
    # Apply classification rules (in order of priority)
    # Class 5: distance < 200 AND speed > 30
    mask_5 = (relative_distance < 200) & (debris_speed > 30)
    target[mask_5] = 5
    
    # Class 4: distance < 400 AND speed > 25 (and not already classified)
    mask_4 = (relative_distance < 400) & (debris_speed > 25) & (target == 0)
    target[mask_4] = 4
    
    # Class 3: distance < 600 AND speed > 20 (and not already classified)
    mask_3 = (relative_distance < 600) & (debris_speed > 20) & (target == 0)
    target[mask_3] = 3
    
    # Class 2: distance < 800 AND speed > 15 (and not already classified)
    mask_2 = (relative_distance < 800) & (debris_speed > 15) & (target == 0)
    target[mask_2] = 2
    
    # Class 1: distance < 1000 AND speed > 10 (and not already classified)
    mask_1 = (relative_distance < 1000) & (debris_speed > 10) & (target == 0)
    target[mask_1] = 1
    
    # Class 0: everything else (already initialized as 0)
    
    # Create DataFrame
    df = pd.DataFrame({
        'Debris_X': debris_x,
        'Debris_Y': debris_y,
        'Debris_Z': debris_z,
        'Debris_VX': debris_vx,
        'Debris_VY': debris_vy,
        'Debris_VZ': debris_vz,
        'Debris_Speed': debris_speed,
        'Relative_Distance': relative_distance,
        'Target': target
    })
    
    return df

# Generate initial dataset
print("Generating synthetic debris dataset...")
df_initial = generate_debris_data(100000)

# Check initial class distribution
print("\nInitial class distribution:")
class_counts = df_initial['Target'].value_counts().sort_index()
print(class_counts)
print(f"Percentages:")
for class_id, count in class_counts.items():
    print(f"Class {class_id}: {count/len(df_initial)*100:.2f}%")